console.log('lala.js loaded');

lala = function(){
    // ini
    var div = document.createElement('div')
    document.body.innerHTML=''
    document.body.appendChild(div)
    var h='<h3 style="color:maroon">lala</h3>'
    h += '<input id="x"> + <input id="y"> = <span id="z">...</span>'
    div.innerHTML=h
    x.onkeyup=y.onkeyup=function(){
        var xv = parseFloat(x.value)
        var yv = parseFloat(y.value)
        var zv = xv+yv
        if(!isNaN(zv)){
            z.textContent=zv
        }
        
    }
    

}







// ini
lala()
